Warning: Please do not change anything in core folder as it may affect files synchronisation.
In other words you won't be able to update NET.ts template with the latest changes.
