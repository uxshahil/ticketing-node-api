enum TicketStatus {
  Unassigned = 'unassigned',
  Open = 'open',
  Paused = 'paused',
  Closed = 'closed',
}

export default TicketStatus;
