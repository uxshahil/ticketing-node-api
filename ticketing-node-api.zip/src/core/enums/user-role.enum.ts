const enum UserRole {
  Admin = 'admin',
  Employee = 'employee',
  SuperAdmin = 'superadmin',
}

export default UserRole;
