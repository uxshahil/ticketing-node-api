enum TicketPriority {
  Low = 'low',
  Medium = 'medium',
  High = 'high',
}

export default TicketPriority;
