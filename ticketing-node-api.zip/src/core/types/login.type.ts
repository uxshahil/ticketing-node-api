export type LoginT = {
  id: string;
  email: string;
  password: string;
  jwt?: string;
};
