export type UserT = {
  id: string;
  firstName: string;
  lastName?: string;
  profilePic?: string;
};
