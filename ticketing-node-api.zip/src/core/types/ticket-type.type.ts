export type TicketTypeT = {
  id: string;
  title: string;
  description: string;
};
