export type SortT = { column: string; order: 'desc' | 'asc' };
