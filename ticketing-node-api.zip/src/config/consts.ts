const API_ROOT_PATH = `/v1`;
const API_DOCS_PATH = '/api-docs';

export default { API_ROOT_PATH, API_DOCS_PATH };
